#include <cassert>
#include <iomanip>
#include <iostream>

#include "project4.hpp"
#include "History.hpp"
#include "Transaction.hpp"

////////////////////////////////////////////////////////////////////////////////
// Definitions for Transaction class
////////////////////////////////////////////////////////////////////////////////
//
//

// Constructor
// TODO
Transaction::Transaction(std::string ticker_symbol,  unsigned int day_date,  
        unsigned int month_date,  unsigned int year_date, 
        bool buy_sell_trans,  unsigned int number_shares,  
        double trans_amount): 
  symbol{ticker_symbol},
  day{day_date},
  month{month_date},
  year{year_date},
  
  trans_type{buy_sell_trans ? "Buy" : "Sell"},
  shares{number_shares},
  amount{trans_amount},

  //--------
  trans_id{assigned_trans_id},
//----------

  acb{},
  acb_per_share{},
  share_balance{},
  cgl{},
  p_next{nullptr}

  { ++assigned_trans_id;  
  }



  //----no overload


  // A unique identifier class variable to assign identifiers (trans_id).
  //



// Destructor
// TODO
Transaction::~Transaction(){
  //delete *p_next;

  day = 0;
  month = 0;
  year = 0;
  symbol = "";
  trans_type = "";
  shares = 0;
  amount = 0;
  trans_id = 0;
  delete p_next;
  p_next = nullptr;
}

// Overloaded < operator.
// TODO
bool Transaction::operator<( Transaction const &other ){
  if(year < other.year){
    return true;
  }
  else if(year > other.year){
    return false;
  }
  if(month < other.month){
    return true;
  }
  else if(month > other.month){
    return false;
  }
  if(day < other.day){
    return true;
  }
  else if(day > other.day){
    return false;
  }
  if(trans_id < other.trans_id){
    return true;
  }
  else if(trans_id > other.trans_id){
    return false;
  }
  return false;
}
//g++ -std=c++11 History_Transaction_definitions.cpp project4.cpp main.cpp -o main
// GIVEN
// Member functions to get values.
//
std::string Transaction::get_symbol() const { return symbol; }
unsigned int Transaction::get_day() const { return day; }
unsigned int Transaction::get_month() const { return month; }
unsigned int Transaction::get_year() const { return year; }
unsigned int Transaction::get_shares() const { return shares; }
double Transaction::get_amount() const { return amount; }
double Transaction::get_acb() const { return acb; }
double Transaction::get_acb_per_share() const { return acb_per_share; }
unsigned int Transaction::get_share_balance() const { return share_balance; }
double Transaction::get_cgl() const { return cgl; }
bool Transaction::get_trans_type() const { return (trans_type == "Buy") ? true: false ; }
unsigned int Transaction::get_trans_id() const { return trans_id; }
Transaction *Transaction::get_next() { return p_next; }

// GIVEN
// Member functions to set values.
//
void Transaction::set_acb( double acb_value ) { acb = acb_value; }
void Transaction::set_acb_per_share( double acb_share_value ) { acb_per_share = acb_share_value; }
void Transaction::set_share_balance( unsigned int bal ) { share_balance = bal ; }
void Transaction::set_cgl( double value ) { cgl = value; }
void Transaction::set_next( Transaction *p_new_next ) { p_next = p_new_next; }

// GIVEN
// Print the transaction.
//
void Transaction::print() {
  std::cout << std::fixed << std::setprecision(2);
  std::cout << std::setw(4) << get_trans_id() << " "
    << std::setw(4) << get_symbol() << " "
    << std::setw(4) << get_day() << " "
    << std::setw(4) << get_month() << " "
    << std::setw(4) << get_year() << " ";


  if ( get_trans_type() ) {
    std::cout << "  Buy  ";
  } else { std::cout << "  Sell "; }

  std::cout << std::setw(4) << get_shares() << " "
    << std::setw(10) << get_amount() << " "
    << std::setw(10) << get_acb() << " " << std::setw(4) << get_share_balance() << " "
    << std::setw(10) << std::setprecision(3) << get_acb_per_share() << " "
    << std::setw(10) << std::setprecision(3) << get_cgl()
    << std::endl;
}


////////////////////////////////////////////////////////////////////////////////
// Definitions for the History class
////////////////////////////////////////////////////////////////////////////////
//
//


// Constructor
// TODO
History::History():
p_head{nullptr}
{}

// Destructor
// TODO
History::~History(){
  // if(p_head = nullptr){
  //   delete p_head;
  // }
  // else{
  //   Transaction *p_old_head{ p_head };
  //   p_head = p_head->get_next();
  //   ~History();
  // }


  // std::cout << p_head << "yeet" << std::endl;
  // std::cout << (p_head->get_next()) << "yeet" << std::endl;
  // std::cout << (p_head->get_next())->get_next() << "yeet" << std::endl;
  // std::cout << (p_head->get_next())->get_next()->get_next() << "yeet" << std::endl;
  // std::cout << (p_head->get_next())->get_next()->get_next()->get_next() << "yeet" << std::endl;
  // std::cout << (p_head->get_next())->get_next()->get_next()->get_next()->get_next() << "yeet" << std::endl;

  // Transaction *a = (p_head);
  // Transaction *b = (p_head->get_next());
  // Transaction *c = (p_head->get_next())->get_next();
  // Transaction *d = (p_head->get_next())->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next();
  // Transaction *e = (p_head->get_next())->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next()->get_next();
  // //Transaction *p_next_head{ p_head };
  //   std::cout << a << std::endl;
  // //std::cout << &t1 << std::endl;
  // std::cout << b << std::endl;
  // //std::cout << &t2 << std::endl;
  // std::cout << c << std::endl;
  // //std::cout << &t3 << std::endl;
  // std::cout << d << std::endl;
  // //std::cout << &t4 << std::endl;
  // std::cout << e << std::endl;
  Transaction *p_old_head{ p_head };
  while(p_head != nullptr){ //This runs twice because transaction's destructor auto loops so
    //std::cout << p_old_head << "oiii" << p_head -> get_next() << std::endl;
    p_head = (p_head -> get_next());
    //std::cout << p_head -> get_next() <<std::endl;
    p_old_head->~Transaction();
    // p_old_head = nullptr;
    //delete p_old_head;
    // p_old_head->~Transaction();
    // delete p_old_head;
    //p_old_head = nullptr;
    //std::cout<<"didit";
  }
  delete p_old_head;}
  // a->print();
  // b->print();
  // c->print();
  // d->print();
//   // e->print();
//   a = new Transaction{"XXXX",  15,  
//       6,  2003, 
//       false, 5,  
//       53.3252};
//   b = new Transaction{"XXXX",  15,  
//       6,  2003, 
//       false, 5,  
//       53.3252};
//   c = new Transaction{"XXXX",  15,  
//       6,  2003, 
//       false, 5,  
//       53.3252};
//   d = new Transaction{"XXXX",  15,  
//       6,  2003, 
//       false, 5,  
//       53.3252};
//   e = new Transaction{"XXXX",  15,  
//       6,  2003, 
//       false, 5,  
//       53.3252};
//   a->print();
//   b->print();
//   c->print();
//   d->print();
//   e->print();
//   std::cout << a << std::endl;
//   //std::cout << &t1 << std::endl;
//   std::cout << b << std::endl;
//   //std::cout << &t2 << std::endl;
//   std::cout << c << std::endl;
//   //std::cout << &t3 << std::endl;
//   std::cout << d << std::endl;
//   //std::cout << &t4 << std::endl;
//   std::cout << e << std::endl;
//   //std::cout << &t5 << std::endl;
// }

// insert(...): Insert transaction into linked list.
// TODO
void History::insert(Transaction *p_new_trans){
  // Transaction *p_temp{p_head};
  // p_head = new Transaction{p_new_trans->get_symbol(), p_new_trans->get_day(), 
  // p_new_trans->get_month(), p_new_trans->get_year(), p_new_trans->get_trans_type(), 
  // p_new_trans->get_shares(), p_new_trans->get_amount()};
  // p_head->set_next(p_temp); //GUESS I WAS RIGHT THE FIRST TIMEEEEE LOOP THRU LIST
  //delete p_temp;
  // p_temp = nullptr;//guess not...



  // p_new_trans->set_next(p_head);
  // p_head = p_new_trans;




  Transaction *p_seek{p_head};
  if(p_seek == nullptr){
    p_head = p_new_trans;
    p_head -> set_next(nullptr);
    return;
  }
  
  while(true){
    if(p_seek -> get_next() == nullptr){
      p_seek -> set_next(p_new_trans);
      p_new_trans->set_next(nullptr);
      return;
    }
    else{
    p_seek = p_seek -> get_next();
  }
  }
  
}
// read_history(...): Read the transaction history from file.
// TODO
void History::read_history(){
  // ece150::open_file();
  // if(ece150::next_trans_entry()){
  // p_head = new Transaction{ece150::get_trans_symbol(), ece150::get_trans_day(), 
  // ece150::get_trans_month(), ece150::get_trans_year(), ece150::get_trans_type(), 
  // ece150::get_trans_shares(), ece150::get_trans_amount()};

  // }
  // Transaction *p_temp{p_head};
  // while(ece150::next_trans_entry()){
  //   p_temp ->set_next(new Transaction{ece150::get_trans_symbol(), ece150::get_trans_day(), 
  // ece150::get_trans_month(), ece150::get_trans_year(), ece150::get_trans_type(), 
  // ece150::get_trans_shares(), ece150::get_trans_amount()});
  // p_temp = p_temp->get_next();}


  //USING NEW INSERT FUNC: frick it messes up the trans ids, but i can fix that if i put --assignedtransid before it, but its slower so ill just use the code i made already
  ece150::open_file();
  while(ece150::next_trans_entry()){
  insert(new Transaction{ece150::get_trans_symbol(), ece150::get_trans_day(), 
  ece150::get_trans_month(), ece150::get_trans_year(), ece150::get_trans_type(), 
  ece150::get_trans_shares(), ece150::get_trans_amount()});
  //std::cout<<"iterated"<<std::endl;
  }
  // insert(new Transaction{ece150::get_trans_symbol(), ece150::get_trans_day(), 
  // ece150::get_trans_month(), ece150::get_trans_year(), ece150::get_trans_type(), 
  // ece150::get_trans_shares(), ece150::get_trans_amount()});
  ece150::close_file();
}
// print() Print the transaction history.
// TODO
void History::print(){
  std::cout << "========== BEGIN TRANSACTION HISTORY ============" <<std::endl;
  Transaction *p_seek{p_head};
  while(p_seek != nullptr){
    p_seek -> print();
    p_seek = p_seek -> get_next();
  }
  //delete p_seek;
  std::cout << "========== END TRANSACTION HISTORY ============" <<std::endl;
}
// sort_by_date(): Sort the linked list by trade date.
// TODO
void History::sort_by_date(){
    if(p_head == nullptr){
      return;
    }
    if(p_head->get_next() == nullptr){
      return;
    }
  Transaction *temp1 = p_head->get_next();
  Transaction *current1 = p_head;
  while (temp1 != nullptr) {
    // if(temp->get_next() == nullptr){
    //   if(*temp < *p_head ){
        
    //   }
    // }
    if (!(*temp1 < *current1)) {
        current1 = temp1;
    }
    temp1 = temp1->get_next();
  }
Transaction *current = p_head;
int yea = 0;
  while (current->get_next() != nullptr) {
 
  //Transaction *tempprev = previous;
  Transaction *p_max = current->get_next();
  Transaction *temp = current->get_next();

  while (temp != nullptr) {
    // if(temp->get_next() == nullptr){
    //   if(*temp < *p_head ){
        
    //   }
    // }
    if (*p_max < *temp) {
        p_max = temp;
    }
    temp = temp->get_next();
  }
   //std::cout<< p_max-> get_year()<<std::endl;
  //Transaction *temp4 = current->get_next(); //ok nevermind but it said this b4: use the same var twice for different thing, NOT SAME OK
  
  // Swap
  //std::cout << p_max->get_year() << p_head->get_year()<<std::endl;
  if((*p_max<*p_head) or (yea ==0)){
    Transaction *swapper = p_head;

    p_head = p_max;
    Transaction *swapper2 = p_max->get_next();
    p_max->set_next(swapper);
    while(swapper != nullptr){
      if(swapper->get_next() == p_head){
        swapper->set_next(swapper2);
      }
      swapper = swapper->get_next();

    }
  }
  else{
    return;
  }
  current = current1;
  yea++;
  }
}

// std::string symbol(current->get_symbol());
// unsigned int day(current->get_day());
// unsigned int month(current->get_month());
// unsigned int year(current->get_year());
// unsigned int shares(current->get_shares());
// double amount(current->get_amount());
// bool type(current->get_trans_type());
// unsigned int id(current->get_trans_id());


  //tempprev = tempprev -> get_next()

//   if(p_head == nullptr){
//     return;
//   }
//   if(p_head->get_next()==nullptr){
//     return;
//   }
//   Transaction *p_seeker{p_head->get_next()};
  
//   while(p_seeker != nullptr){
//     if(!( *p_seeker < *p_head)){
//       Transaction *p_temp = p_head;
//       p_head = p_seeker;
//       p_head ->set_next(p_temp);
//     }
//     p_seeker = p_seeker -> get_next();
//   }
// }
// update_acb_cgl(): Updates the ACB and CGL values.
// TODO
void History::update_acb_cgl(){
  Transaction *temp = p_head;
  double current_acb = 0;
  int current_shares = 0;
  //double current_cgl = 0;
  double current_acbps = 0;
  while (temp != nullptr){
    if(temp->get_trans_type() == true){ // buy

    current_acb+= temp->get_amount();
    current_shares += temp->get_shares();
    current_acbps = (current_acb/current_shares);
    temp->set_acb_per_share(current_acb/current_shares);
    temp->set_share_balance(current_shares);
    temp->set_acb(current_acb);
    temp->set_cgl(0);

    temp = temp->get_next();
    }
    else{
      current_acb -= (temp->get_shares()*current_acbps);
      current_shares -= (temp->get_shares());
      //current_cgl = ();
      temp->set_acb_per_share(current_acb/current_shares);
      temp->set_share_balance(current_shares);
      temp->set_acb(current_acb);
      temp->set_cgl(0);

      temp = temp->get_next();
    }
  }
  temp = p_head;
  while (temp != nullptr){
    if(temp->get_trans_type() == false){
      temp->set_cgl(temp->get_amount()-(temp->get_shares()*temp->get_acb_per_share()));
    }
  
    temp = temp->get_next();
  }
}
// compute_cgl(): )Compute the ACB, and CGL.
// TODO
double History::compute_cgl(unsigned int year){
  Transaction *temp{p_head};
  //std::cout<<temp->get_year();
  double counter{0};
  while (temp != nullptr){
    if(temp->get_year() == year){
      counter += temp->get_cgl();
    }
  
    temp = temp->get_next();

}
return counter;
}

// get_p_head(): Full access to the linked list.
//
Transaction *History::get_p_head() { return p_head; }



