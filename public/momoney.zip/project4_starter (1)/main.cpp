#include <iostream>
#include "History.hpp"
#include "Transaction.hpp"


#ifndef MARMOSET_TESTING
unsigned int Transaction::assigned_trans_id = 0;
int main() {


  History trans_history{};
std::cout << "CREATED" << std::endl;

  trans_history.read_history();
std::cout << "READ" << std::endl;
  std::cout << "[Starting history]:" << std::endl;
  trans_history.print();
 // trans_history.~History();
  trans_history.sort_by_date();

  std::cout << "[Sorted          ]:" << std::endl;
  trans_history.print();

  trans_history.update_acb_cgl();
  trans_history.print();

  std::cout << "[CGL for 2018    ]: " << trans_history.compute_cgl(2018) << std::endl;
  std::cout << "[CGL for 2019    ]: " << trans_history.compute_cgl(2019) << std::endl;

//   trans_history.insert(new Transaction {"XXXX",  10,  
//         6,  2003, 
//         true, 5,  
//         53.3252});
  //trans_history.print();
      // trans_history.print();
      // trans_history.~History();
      //trans_history.print();
      
//   Transaction t1{"XXXX",  15,  
//         6,  2003, 
//         false, 5,  
//         53.3252};
//   Transaction t2{"XXXX",  10,  
//         6,  2003, 
//         true, 5,  
//         53.3252};
//   std::cout << (t1.get_trans_type()) << std::endl;
//   std::cout << (t1.get_day()) << std::endl;
//   std::cout << (t1.get_month()) << std::endl;
//   std::cout << (t1.get_year()) << std::endl;
//   std::cout << (t1.get_amount()) << std::endl;
//   std::cout << (t1.get_shares()) << std::endl;
//   std::cout << (t1.get_symbol()) << std::endl;


  return 0;
}
#endif
