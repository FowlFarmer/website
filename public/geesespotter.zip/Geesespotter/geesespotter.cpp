#include <iostream>
#include "geesespotter_lib.h"




char * create_board(std::size_t x_dim, std::size_t y_dim) {
    char* board = new char[x_dim * y_dim];
    for(int i{0}; i < (x_dim*y_dim); ++i) {
        board[i] = '\0'; //might need \0
    }
return board;
}
void clean_board(char * board) {
    delete[] board;
return;
}
void print_board(char * board, std::size_t x_dim, std::size_t y_dim) {
    for(int i{0}; i<y_dim; ++i) {
        for(int j{0}; j<x_dim; ++j){
            if((board[(i*x_dim)+j] & marked_mask()) != 0){
                std::cout << 'M';
            }
            else if((board[(i*x_dim)+j] & hidden_mask()) != 0){
                std::cout << '*';
            }
            else{
                int actualValue{0};
                if((board[(i*x_dim)+j] & 0x01) != 0){
                    actualValue +=1;
                }
                if((board[(i*x_dim)+j] & 0x02) != 0){
                    actualValue +=2;
                }
                if((board[(i*x_dim)+j] & 0x04) != 0){
                    actualValue +=4;
                }
                if((board[(i*x_dim)+j] & 0x08) != 0){
                    actualValue +=8;
                }
                std::cout << actualValue;
            }
        }
        std::cout << std::endl;
    }
return;
}
void hide_board(char * board, std::size_t x_dim, std::size_t y_dim) {
    for(int i{0}; i<(x_dim*y_dim); ++i){
        board[i] = (board[i] | hidden_mask());
    }
return;
}
int mark(char * board, std::size_t x_dim, std::size_t y_dim, std::size_t x_loc, std::size_t y_loc) {
    if((board[(x_dim*y_loc)+x_loc] & hidden_mask()) == 0){
        return 2;
    }
    else{
        board[(x_dim*y_loc)+x_loc] = (board[(x_dim*y_loc)+x_loc] ^ marked_mask());
    }
return 0;
}

void compute_neighbours(char * board, std::size_t x_dim, std::size_t y_dim) {
    for(int i{0}; i<(x_dim*y_dim); ++i) {
        if((board[i] & 0x0F) == 9){
            // if(InBoard(board[i], x_dim, y_dim)){
            //     ++board[i+1];
            // }
            // if(board[i-1]>=0){
            //     ++board[i-1];
            // }
            // for(int j{0}; j<3; ++j){
            //     if(InBoard(board[(i-x_dim)-1+j], x_dim, y_dim)){

            //     }
            // }
            // for(int j{0}; j<3; ++j){
                
            // }
            bool right{0};
            bool left{0};
            bool top{0};
            bool bottom{0};
            if((i+1)%(x_dim)==0){
                right = true;
            }
            if((i+1)%(x_dim)==1){
                left = true;
            }
            if(i<x_dim){
                top = true;
            }
            if(i>=(x_dim*(y_dim-1))){
                bottom = true;
            }

//----------------------- UGHGHGHGHGHG

            if(!top){
                ++board[i-x_dim];
            }
            if(!left && !top){
                    ++board[i-1-x_dim];
                }
            if(!right && !top){
                    ++board[i+1-x_dim];
                }
            if(!right){
                ++board[i+1];
            }
            if(!left){
                ++board[i-1];
            }
            if(!bottom){
                ++board[i+x_dim];
            }
            if(!right && !bottom){
                    ++board[i+1+x_dim];
                }
            if(!left && !bottom){
                    ++board[i-1+x_dim];
                }
        }
    }
return;
}
bool is_game_won(char * board, std::size_t x_dim, std::size_t y_dim) {
    for(int i{0}; i<(x_dim*y_dim); ++i) {
        if((board[i]& value_mask()) != 9) {
            if((board[i] & hidden_mask()) != 0){
                return false;
            }
        }
    }
return true;
}
int reveal(char * board, std::size_t x_dim, std::size_t y_dim, std::size_t x_loc, std::size_t y_loc) {
    if((board[x_dim*y_loc+x_loc]&marked_mask())!=0) { // if marked
        return 1;
    }
    if((board[x_dim*y_loc+x_loc]&hidden_mask())==0) { // if revealed already
        return 2;
    }
    if((board[x_dim*y_loc+x_loc]&value_mask())==9) {
        board[x_dim*y_loc+x_loc] |= hidden_mask();
        return 9;
    }
    board[x_dim*y_loc+x_loc] |= hidden_mask();
    board[x_dim*y_loc+x_loc] ^= hidden_mask();

    if((board[x_dim*y_loc+x_loc] & value_mask())==0) {
        bool right{0};
        bool left{0};
        bool top{0};
        bool bottom{0};
        if(((x_dim*y_loc+x_loc)+1)%(x_dim)==0){
            right = true;
        }
        if(((x_dim*y_loc+x_loc)+1)%(x_dim)==1){
            left = true;
        }
        if((x_dim*y_loc+x_loc)<x_dim){
            top = true;
        }
        if((x_dim*y_loc+x_loc)>=(x_dim*(y_dim-1))){
            bottom = true;
        }

        if(!top){
                board[(x_dim*y_loc+x_loc)-x_dim] |= hidden_mask();
                board[(x_dim*y_loc+x_loc)-x_dim] ^= hidden_mask();
            }
            if(!right && !top){
                    board[(x_dim*y_loc+x_loc)+1-x_dim] |= hidden_mask();
                    board[(x_dim*y_loc+x_loc)+1-x_dim] ^= hidden_mask();
                }
            if(!left && !top){
                    board[(x_dim*y_loc+x_loc)-1-x_dim] |= hidden_mask();
                    board[(x_dim*y_loc+x_loc)-1-x_dim] ^= hidden_mask();
                }
            if(!right){
                board[(x_dim*y_loc+x_loc)+1] |= hidden_mask();
                board[(x_dim*y_loc+x_loc)+1] ^= hidden_mask();
            }
            if(!left){
                board[(x_dim*y_loc+x_loc)-1] |= hidden_mask();
                board[(x_dim*y_loc+x_loc)-1] ^= hidden_mask();
            }
            if(!bottom){
                board[(x_dim*y_loc+x_loc)+x_dim] |= hidden_mask();
                board[(x_dim*y_loc+x_loc)+x_dim] ^= hidden_mask();
            }
            if(!right && !bottom){
                    board[(x_dim*y_loc+x_loc)+1+x_dim] |= hidden_mask();
                    board[(x_dim*y_loc+x_loc)+1+x_dim] ^= hidden_mask();
                }
            if(!left && !bottom){
                    board[(x_dim*y_loc+x_loc)-1+x_dim] |= hidden_mask();
                    board[(x_dim*y_loc+x_loc)-1+x_dim] ^= hidden_mask();
                }

    }
    return 0;
    // FUCK I AVE TO DO ALL OVER AGAIN THAT LOGIV C CRAP
}
